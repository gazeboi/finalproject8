/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package form;

import dbkel8.Koneksi;
import java.sql.Connection;
import javax.swing.table.DefaultTableModel;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;


public class FormTransaksi extends javax.swing.JFrame {

    private Connection conn;
    
    public FormTransaksi() {
        initComponents();
        conn = Koneksi.getConnection();
        getData();
    }
    
    
    
        

    private void getData(){
        DefaultTableModel model =(DefaultTableModel) TabelProduk1.getModel();
        model.setRowCount(0);
        
        
        try{
            String sql = "Select * From produk ";
            PreparedStatement st = conn.prepareStatement(sql);
            ResultSet rs = st.executeQuery();
            
            while(rs.next()){
                String nomor = rs.getString("nomor");
                String nama = rs.getString("nama");
                String jenis = rs.getString("jenis");
                String harga = rs.getString("harga");
                String stock = rs.getString("stock");
                
                Object[] rowData = {nomor,nama,jenis,harga,stock};
                model.addRow(rowData);
                
            }
            
            rs.close();
            st.close();
        }catch (Exception e){
            Logger.getLogger(FormProduk.class.getName()).log(Level.SEVERE, null,e);
            
        }
    }
    
    
    
    
   
//   private void tampiltransaksi(){
//        DefaultTableModel model =(DefaultTableModel) tabel2.getModel();
//        model.setRowCount(0);
//        
//        
//        try{
//            String sql = "Select * From transaksi";
//            PreparedStatement st = conn.prepareStatement(sql);
//            ResultSet rs = st.executeQuery();
//            
//            while(rs.next()){
//                String nomor = rs.getString("nomorOrder");
//                String nama = rs.getString("namaProduk");
//                String harga = rs.getString("harga");
//                String total = rs.getString("total");
//                String jumlah = rs.getString("jumlah");
//                
//                
//                Object[] rowData = {nomor,nama,harga,total,jumlah,};
//                model.addRow(rowData);
//                
//            }
//            
//            rs.close();
//            st.close();
//        }catch (Exception e){
//            Logger.getLogger(FormProduk.class.getName()).log(Level.SEVERE, null,e);
//            
//        }
//    }
   

private void resetForm() {
        nomorp_txt.setText("");
        jumlah_txt.setText("");
        
        
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        nomorp_txt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jumlah_txt = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        TabelProduk1 = new javax.swing.JTable();
        keranjang = new javax.swing.JButton();
        jToggleButton1 = new javax.swing.JToggleButton();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setFont(new java.awt.Font("MV Boli", 0, 24)); // NOI18N
        jLabel1.setText("TRANSAKSI");

        jLabel3.setText("Nomor Produk");

        nomorp_txt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nomorp_txtActionPerformed(evt);
            }
        });

        jLabel4.setText("Jumlah/Qty.");

        TabelProduk1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Nomor Product", "Nama Product", "Jenis Produk", "Harga", "Stock"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.Object.class, java.lang.Integer.class, java.lang.Integer.class
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }
        });
        TabelProduk1.setShowGrid(true);
        TabelProduk1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                TabelProduk1MouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(TabelProduk1);

        keranjang.setText("Check Out");
        keranjang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                keranjangActionPerformed(evt);
            }
        });

        jToggleButton1.setText("Tampilkan Riwayat Transaksi >>");
        jToggleButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jToggleButton1ActionPerformed(evt);
            }
        });

        jButton1.setText("<< Kembali ke Produk");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 103, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4)
                            .addComponent(jLabel3))
                        .addGap(63, 63, 63)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(keranjang)
                    .addComponent(nomorp_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jumlah_txt, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(jLabel1)))
                .addGap(46, 46, 46)
                .addComponent(jToggleButton1)
                .addGap(19, 19, 19))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(91, 91, 91)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 503, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(90, Short.MAX_VALUE)))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jButton1)
                            .addComponent(jToggleButton1)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(jLabel1)))
                .addGap(370, 370, 370)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nomorp_txt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jumlah_txt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addComponent(keranjang)
                .addContainerGap(69, Short.MAX_VALUE))
            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(layout.createSequentialGroup()
                    .addGap(78, 78, 78)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 327, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(198, Short.MAX_VALUE)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void TabelProduk1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_TabelProduk1MouseClicked
        
    }//GEN-LAST:event_TabelProduk1MouseClicked

    private void nomorp_txtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nomorp_txtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nomorp_txtActionPerformed

    private void keranjangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_keranjangActionPerformed
         String nomorp = nomorp_txt.getText();

try {
    String sql = "SELECT * FROM produk WHERE nomor LIKE '%" + nomorp + "%'";
    PreparedStatement st = conn.prepareStatement(sql);
    ResultSet rs = st.executeQuery();

    while (rs.next()) {
        String nomor = rs.getString("nomor");
        String nama = rs.getString("nama");
        String jenis = rs.getString("jenis");
        String harga = rs.getString("harga");
        String stock = rs.getString("stock");
        String jumlah = jumlah_txt.getText();

        int intstock = Integer.parseInt(stock);
        int intjumlah = Integer.parseInt(jumlah);
        int intharga = Integer.parseInt(harga);
        int total = intjumlah * intharga;

        // Check if there is enough stock
        if (intjumlah <= intstock) {
            // Update stock in produk table
            try {
                String updateStockSql = "UPDATE produk SET stock = ? WHERE nomor = ?";
                PreparedStatement updateStockSt = conn.prepareStatement(updateStockSql);
                updateStockSt.setInt(1, intstock - intjumlah);
                updateStockSt.setString(2, nomor);
                updateStockSt.executeUpdate();
                updateStockSt.close();
            } catch (Exception e) {
                Logger.getLogger(FormProduk.class.getName()).log(Level.SEVERE, null, e);
            }

            // Insert data into transaksi table
            try {
                String insertTransaksiSql = "INSERT INTO transaksi (nomorOrder, namaProduk, harga,  total, jumlah) VALUES (?, ?, ?, ?, ?)";
                PreparedStatement insertSt = conn.prepareStatement(insertTransaksiSql);
                insertSt.setString(1, nomor);
                insertSt.setString(2, nama);
                insertSt.setInt(3, intharga);
                insertSt.setInt(4, total);
                insertSt.setInt(5, intjumlah);
                int rowInserted = insertSt.executeUpdate();

                if (rowInserted > 0) {
                    JOptionPane.showMessageDialog(this, "Berhasil di checkout !");
                    resetForm();
                    getData();
                }
                insertSt.close();
            } catch (Exception e) {
                Logger.getLogger(FormProduk.class.getName()).log(Level.SEVERE, null, e);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Stock tidak mencukupi!");
        }
    }

    rs.close();
    st.close();
} catch (Exception e) {
    Logger.getLogger(FormProduk.class.getName()).log(Level.SEVERE, null, e);
}


            
            
            
            
        
    
            
        
          
          
        

    }//GEN-LAST:event_keranjangActionPerformed

    private void jToggleButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jToggleButton1ActionPerformed
        
        history history = new history();
        history.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jToggleButton1ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        FormProduk produk = new FormProduk();
        produk.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FormTransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FormTransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FormTransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FormTransaksi.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FormTransaksi().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TabelProduk1;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JToggleButton jToggleButton1;
    private javax.swing.JTextField jumlah_txt;
    private javax.swing.JButton keranjang;
    private javax.swing.JTextField nomorp_txt;
    // End of variables declaration//GEN-END:variables
}
